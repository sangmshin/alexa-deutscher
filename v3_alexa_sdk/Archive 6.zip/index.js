"use strict";
const Alexa = require("alexa-sdk"); // import the library

//=========================================================================================================================================
//TODO: The items below this comment need your attention
//=========================================================================================================================================

//Replace with your app ID (OPTIONAL).  You can find this value at the top of your skill's page on http://developer.amazon.com.
//Make sure to enclose your value in quotes, like this:  var APP_ID = "amzn1.ask.skill.bb4045e6-b3e8-4133-b650-72923c5980f1";
var APP_ID = 'amzn1.ask.skill.0897f940-a3b2-4f50-943b-821e3ab79ed0';

// =====================================================================================================
// --------------------------------- Section 1. Data and Text strings  ---------------------------------
// =====================================================================================================
//TODO: Replace this data with your own.
//======================================================================================================

var data = [{
        "fullname": "Andy Achsen",
        "firstName": "Andy",
        "lastName": "Achsen",
        "cityName": "new york",
        "department": "Art and Print Prod-NY",
        "title": "Proofreader",
        "number": "212-981-7903",
        "seatlocation": "1322-37",
        "gender": "m"
    },
    {
        "fullname": "Samantha Addy",
        "firstName": "Samantha",
        "lastName": "Addy",
        "cityName": "new york",
        "department": "Content Production",
        "title": "Associate Producer",
        "number": "212-981-7731",
        "seatlocation": "1322-26",
        "gender": "f"
    },
    {
        "fullname": "Kemi Adewumi",
        "firstName": "Kemi",
        "lastName": "Adewumi",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Supervisor",
        "number": "212-981-7626",
        "seatlocation": "1433-04",
        "gender": "f"
    },
    {
        "fullname": "Carlos Agosto",
        "firstName": "Carlos",
        "lastName": "Agosto",
        "cityName": "new york",
        "department": "Digital Creative",
        "title": "Senior Digital Developer",
        "number": "212-981-7801",
        "seatlocation": "1420-24",
        "gender": "m"
    },
    {
        "fullname": "Anastasia Agrapides",
        "firstName": "Anastasia",
        "lastName": "Agrapides",
        "cityName": "new york",
        "department": "Integrated Business Affairs",
        "title": "Business Affairs Coordinator",
        "number": "212-981-7560",
        "seatlocation": "1322-31",
        "gender": "f"
    },
    {
        "fullname": "Virginia Albert",
        "firstName": "Virginia",
        "lastName": "Albert",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Executive",
        "number": "212-981-8085",
        "seatlocation": "1312-07",
        "gender": "f"
    },
    {
        "fullname": "Joseph Amat",
        "firstName": "Joseph",
        "lastName": "Amat",
        "cityName": "new york",
        "department": "Media",
        "title": "Assistant Media Planner",
        "number": "212-981-7707",
        "seatlocation": "1312-09",
        "gender": "m"
    },
    {
        "fullname": "Cohan Andersen",
        "firstName": "Cohan",
        "lastName": "Andersen",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "Editor",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Viktor Angwald",
        "firstName": "Viktor",
        "lastName": "Angwald",
        "cityName": "new york",
        "department": "Creative",
        "title": "Copywriter",
        "number": "212-981-8064",
        "seatlocation": "1415-16",
        "gender": "m"
    },
    {
        "fullname": "Sheldon Anthony",
        "firstName": "Sheldon",
        "lastName": "Anthony",
        "cityName": "new york",
        "department": "Studio",
        "title": "Graphics Business Manager",
        "number": "212-981-7630",
        "seatlocation": "1322-43",
        "gender": "m"
    },
    {
        "fullname": "Becca Antonucci",
        "firstName": "Becca",
        "lastName": "Antonucci",
        "cityName": "new york",
        "department": "Creative",
        "title": "Copywriter",
        "number": "212-981-7753",
        "seatlocation": "1420-25",
        "gender": "f"
    },
    {
        "fullname": "Gabriel Aponte",
        "firstName": "Gabriel",
        "lastName": "Aponte",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Supervisor",
        "number": "212-981-7929",
        "seatlocation": "1433-33",
        "gender": "f"
    },
    {
        "fullname": "Anthony Arfi",
        "firstName": "Anthony",
        "lastName": "Arfi",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "Assistant Editor",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Beth Armstrong",
        "firstName": "Beth",
        "lastName": "Armstrong",
        "cityName": "new york",
        "department": "Creative",
        "title": "Talent Manager",
        "number": "212-981-7955",
        "seatlocation": "1420-47",
        "gender": "f"
    },
    {
        "fullname": "Andrew Arnot",
        "firstName": "Andrew",
        "lastName": "Arnot",
        "cityName": "new york",
        "department": "Account Management",
        "title": "SVP, Account Director",
        "number": "212-981-7826",
        "seatlocation": "1433-02",
        "gender": "m"
    },
    {
        "fullname": "Garett Awad",
        "firstName": "Garett",
        "lastName": "Awad",
        "cityName": "new york",
        "department": "Strategy",
        "title": "VP, Strategist",
        "number": "212-981-8045",
        "seatlocation": "1442-05",
        "gender": "m"
    },
    {
        "fullname": "Scott Axworthy",
        "firstName": "Scott",
        "lastName": "Axworthy",
        "cityName": "new york",
        "department": "Operations",
        "title": "Facilities Coordinator",
        "number": "212-981-7916",
        "seatlocation": "1301-01",
        "gender": "m"
    },
    {
        "fullname": "Nikisha Baboram",
        "firstName": "Nikisha",
        "lastName": "Baboram",
        "cityName": "new york",
        "department": "Finance",
        "title": "Senior Budget Coordinator",
        "number": "212-981-7840",
        "seatlocation": "1312-48",
        "gender": "f"
    },
    {
        "fullname": "Nikki Balekjian",
        "firstName": "Nikki",
        "lastName": "Balekjian",
        "cityName": "new york",
        "department": "Integrated Business Affairs",
        "title": "Integrated Business Affairs Manager",
        "number": "212-981-7894",
        "seatlocation": "1322-30",
        "gender": "f"
    },
    {
        "fullname": "Kate Bauer",
        "firstName": "Kate",
        "lastName": "Bauer",
        "cityName": "new york",
        "department": "Creative",
        "title": "VP, Experience Lead Design",
        "number": "212-981-7830",
        "seatlocation": "1420-66",
        "gender": "f"
    },
    {
        "fullname": "Karen Benson",
        "firstName": "Karen",
        "lastName": "Benson",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "EVP, Director of Integrated Media",
        "number": "212-981-7802",
        "seatlocation": "1307-02",
        "gender": "f"
    },
    {
        "fullname": "Melissa Betancur",
        "firstName": "Melissa",
        "lastName": "Betancur",
        "cityName": "new york",
        "department": "Art and Print Prod-NY",
        "title": "Print Producer",
        "number": "212-651-8489",
        "seatlocation": "1322-40",
        "gender": "f"
    },
    {
        "fullname": "Adrian Binns",
        "firstName": "Adrian",
        "lastName": "Binns",
        "cityName": "new york",
        "department": "Human Resources",
        "title": "Payroll and Benefits Associate",
        "number": "212-981-7581",
        "seatlocation": "1312-40",
        "gender": "m"
    },
    {
        "fullname": "Jonathan Boffa",
        "firstName": "Jonathan",
        "lastName": "Boffa",
        "cityName": "new york",
        "department": "Creative",
        "title": "Designer",
        "number": "212-981-7887",
        "seatlocation": "1420-57",
        "gender": "m"
    },
    {
        "fullname": "Art Boonklan",
        "firstName": "Art",
        "lastName": "Boonklan",
        "cityName": "new york",
        "department": "Creative",
        "title": "Associate Creative Director",
        "number": "212-981-7524",
        "seatlocation": "1415-10",
        "gender": "m"
    },
    {
        "fullname": "Siobhan Brooker",
        "firstName": "Siobhan",
        "lastName": "Brooker",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "Assistant Media Planner",
        "number": "212-981-8047",
        "seatlocation": "1312-10",
        "gender": "f"
    },
    {
        "fullname": "Lauren Brooks",
        "firstName": "Lauren",
        "lastName": "Brooks",
        "cityName": "new york",
        "department": "Creative",
        "title": "UX Designer",
        "number": "212-981-7885",
        "seatlocation": "1420-63",
        "gender": "f"
    },
    {
        "fullname": "Richard Bryan",
        "firstName": "Richard",
        "lastName": "Bryan",
        "cityName": "new york",
        "department": "Finance",
        "title": "Manager, Client Accounting",
        "number": "212-981-7645",
        "seatlocation": "1309-16",
        "gender": "m"
    },
    {
        "fullname": "Maureen Burzynski",
        "firstName": "Maureen",
        "lastName": "Burzynski",
        "cityName": "new york",
        "department": "Media Buying",
        "title": "EVP, Director of Local Buying",
        "number": "212-981-7930",
        "seatlocation": "1307-01",
        "gender": "f"
    },
    {
        "fullname": "Morgan Busch",
        "firstName": "Morgan",
        "lastName": "Busch",
        "cityName": "new york",
        "department": "Media",
        "title": "Paid Search/Social, Assistant",
        "number": "212-981-7893",
        "seatlocation": "1312-27",
        "gender": "f"
    },
    {
        "fullname": "Carla Butwin",
        "firstName": "Carla",
        "lastName": "Butwin",
        "cityName": "new york",
        "department": "Creative",
        "title": "Senior Art Director",
        "number": "212-981-7941",
        "seatlocation": "1415-22|",
        "gender": "f"
    },
    {
        "fullname": "Alexis Bynum",
        "firstName": "Alexis",
        "lastName": "Bynum",
        "cityName": "new york",
        "department": "Art and Print Prod-NY",
        "title": "Art Buyer",
        "number": "212-981-8032",
        "seatlocation": "1322-25",
        "gender": "f"
    },
    {
        "fullname": "Joe Calabrese",
        "firstName": "Joe",
        "lastName": "Calabrese",
        "cityName": "new york",
        "department": "Content Production",
        "title": "EVP, Director of Integrated Production",
        "number": "212-981-8007",
        "seatlocation": "1321-02",
        "gender": "m"
    },
    {
        "fullname": "Kerry Callaghan",
        "firstName": "Kerry",
        "lastName": "Callaghan",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Supervisor",
        "number": "212-981-7587",
        "seatlocation": "1312-04",
        "gender": "f"
    },
    {
        "fullname": "Lauryn Campbell",
        "firstName": "Lauryn",
        "lastName": "Campbell",
        "cityName": "new york",
        "department": "Creative",
        "title": "Art Director",
        "number": "212-981-7819",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Katie Casares",
        "firstName": "Katie",
        "lastName": "Casares",
        "cityName": "new york",
        "department": "Project Management",
        "title": "Digital Project Manager",
        "number": "212-981-7994",
        "seatlocation": "1420-32",
        "gender": "f"
    },
    {
        "fullname": "Eva Cassetta",
        "firstName": "Eva",
        "lastName": "Cassetta",
        "cityName": "new york",
        "department": "Studio",
        "title": "Designer",
        "number": "212-981-7684",
        "seatlocation": "1322-44",
        "gender": "f"
    },
    {
        "fullname": "Ashley Centrella",
        "firstName": "Ashley",
        "lastName": "Centrella",
        "cityName": "new york",
        "department": "Creative",
        "title": "Art Director",
        "number": "212-981-7860",
        "seatlocation": "1420-36",
        "gender": "f"
    },
    {
        "fullname": "Barbara Chandler",
        "firstName": "Barbara",
        "lastName": "Chandler",
        "cityName": "new york",
        "department": "Account Management",
        "title": "EVP, Group Account Director",
        "number": "212-981-7873",
        "seatlocation": "1445-02",
        "gender": "f"
    },
    {
        "fullname": "Sunny Chao",
        "firstName": "Sunny",
        "lastName": "Chao",
        "cityName": "new york",
        "department": "Digital Creative",
        "title": "Creative Developer",
        "number": "212-981-7821",
        "seatlocation": "1420-25",
        "gender": "m"
    },
    {
        "fullname": "Fung Cheung",
        "firstName": "Fung",
        "lastName": "Cheung",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Strategist",
        "number": "212-981-7544",
        "seatlocation": "1420-07",
        "gender": "m"
    },
    {
        "fullname": "Crissy Cicco",
        "firstName": "Crissy",
        "lastName": "Cicco",
        "cityName": "new york",
        "department": "Content Production",
        "title": "Executive Producer",
        "number": "212-981-7648",
        "seatlocation": "1323-16",
        "gender": "f"
    },
    {
        "fullname": "Johnny Cintron",
        "firstName": "Johnny",
        "lastName": "Cintron",
        "cityName": "new york",
        "department": "Operations",
        "title": "Handyman/Facilities Coordinator",
        "number": "212-981-8058",
        "seatlocation": "1301-02",
        "gender": "m"
    },
    {
        "fullname": "Christina Collins",
        "firstName": "Christina",
        "lastName": "Collins",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "Assistant Media Planner",
        "number": "212-981-7799",
        "seatlocation": "1312-16",
        "gender": "f"
    },
    {
        "fullname": "Cara Colucci",
        "firstName": "Cara",
        "lastName": "Colucci",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Senior Planner",
        "number": "212-981-8056",
        "seatlocation": "1442-01",
        "gender": "f"
    },
    {
        "fullname": "Lisa Conneely",
        "firstName": "Lisa",
        "lastName": "Conneely",
        "cityName": "new york",
        "department": "Data Strategy",
        "title": "SVP, Director of Data Analytics",
        "number": "212-651-8464",
        "seatlocation": "1415-07",
        "gender": "f"
    },
    {
        "fullname": "Dan Connelly",
        "firstName": "Dan",
        "lastName": "Connelly",
        "cityName": "new york",
        "department": "Studio",
        "title": "Proofreader",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Maggie O. Connors",
        "firstName": "Maggie",
        "lastName": "O. Connors",
        "cityName": "new york",
        "department": "Business Development",
        "title": "EVP, Head of Business Development",
        "number": "212-981-7797",
        "seatlocation": "1319-02",
        "gender": "f"
    },
    {
        "fullname": "Dean Coots",
        "firstName": "Dean",
        "lastName": "Coots",
        "cityName": "new york",
        "department": "Creative",
        "title": "Copywriter",
        "number": "212-981-7640",
        "seatlocation": "1420-41",
        "gender": "m"
    },
    {
        "fullname": "James Cowie",
        "firstName": "James",
        "lastName": "Cowie",
        "cityName": "new york",
        "department": "Creative",
        "title": "VP, Creative Director",
        "number": "212-981-7719",
        "seatlocation": "1420-41",
        "gender": "m"
    },
    {
        "fullname": "Andrea Curtin",
        "firstName": "Andrea",
        "lastName": "Curtin",
        "cityName": "new york",
        "department": "Content Production",
        "title": "Executive Producer",
        "number": "212-981-8083",
        "seatlocation": "1323-17",
        "gender": "f"
    },
    {
        "fullname": "Chris Cutone",
        "firstName": "Chris",
        "lastName": "Cutone",
        "cityName": "new york",
        "department": "Human Resources",
        "title": "EVP, Director of Human Resources",
        "number": "212-981-7796",
        "seatlocation": "1311-02",
        "gender": "m"
    },
    {
        "fullname": "Laura Czerepak",
        "firstName": "Laura",
        "lastName": "Czerepak",
        "cityName": "new york",
        "department": "Creative",
        "title": "Creative Coordinator",
        "number": "212-981-8023",
        "seatlocation": "1420-47",
        "gender": "f"
    },
    {
        "fullname": "Lindsay D’Ambola",
        "firstName": "Lindsay",
        "lastName": "D’Ambola",
        "cityName": "new york",
        "department": "Media Buying",
        "title": "Supervisor, National Video",
        "number": "212-981-7773",
        "seatlocation": "1312-22",
        "gender": "f"
    },
    {
        "fullname": "Sadeqwa Davis",
        "firstName": "Sadeqwa",
        "lastName": "Davis",
        "cityName": "new york",
        "department": "Administration",
        "title": "Administrative Assistant",
        "number": "212-981-8002",
        "seatlocation": "1433-55",
        "gender": "f"
    },
    {
        "fullname": "George Decker",
        "firstName": "George",
        "lastName": "Decker",
        "cityName": "new york",
        "department": "Creative",
        "title": "EVP, Group Creative Director",
        "number": "212-981-7962",
        "seatlocation": "1415-13",
        "gender": "m"
    },
    {
        "fullname": "Josh Deitel",
        "firstName": "Josh",
        "lastName": "Deitel",
        "cityName": "new york",
        "department": "Digital Production",
        "title": "Executive Digital Producer",
        "number": "212-981-8018",
        "seatlocation": "1322-28",
        "gender": "m"
    },
    {
        "fullname": "Maggie DeLuca",
        "firstName": "Maggie",
        "lastName": "DeLuca",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-7586",
        "seatlocation": "1433-08",
        "gender": "f"
    },
    {
        "fullname": "Kristi Diaz",
        "firstName": "Kristi",
        "lastName": "Diaz",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Director",
        "number": "212-981-7728",
        "seatlocation": "1309-04",
        "gender": "f"
    },
    {
        "fullname": "Suzanne Diegmann",
        "firstName": "Suzanne",
        "lastName": "Diegmann",
        "cityName": "new york",
        "department": "Finance",
        "title": "VP, Finance Director",
        "number": "212-981-7770",
        "seatlocation": "1306-01",
        "gender": "f"
    },
    {
        "fullname": "Val DiFebo",
        "firstName": "Val",
        "lastName": "DiFebo",
        "cityName": "new york",
        "department": "Executive New York",
        "title": "CEO, Deutsch Inc",
        "number": "212-981-7671",
        "seatlocation": 1439,
        "gender": "f"
    },
    {
        "fullname": "Caitlin Dilks",
        "firstName": "Caitlin",
        "lastName": "Dilks",
        "cityName": "new york",
        "department": "Media",
        "title": "Digital Media Supervisor",
        "number": "212-981-7735",
        "seatlocation": "1433-43",
        "gender": "f"
    },
    {
        "fullname": "Julianne Dinsmore",
        "firstName": "Julianne",
        "lastName": "Dinsmore",
        "cityName": "new york",
        "department": "Media Buying",
        "title": "Assistant Media Buyer",
        "number": "212-981-7915",
        "seatlocation": "1312-18",
        "gender": "f"
    },
    {
        "fullname": "Emily Doll",
        "firstName": "Emily",
        "lastName": "Doll",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Supervisor",
        "number": "212-981-7652",
        "seatlocation": "1312-12",
        "gender": "f"
    },
    {
        "fullname": "Michelle Douglas",
        "firstName": "Michelle",
        "lastName": "Douglas",
        "cityName": "new york",
        "department": "Finance",
        "title": "Financial Analyst",
        "number": "212-651-8411",
        "seatlocation": "1312-38",
        "gender": "f"
    },
    {
        "fullname": "Dawn Doumeng",
        "firstName": "Dawn",
        "lastName": "Doumeng",
        "cityName": "new york",
        "department": "Integrated Business Affairs",
        "title": "Senior Business Manager",
        "number": "212-981-7832",
        "seatlocation": "1323-10",
        "gender": "f"
    },
    {
        "fullname": "Estela Duce",
        "firstName": "Estela",
        "lastName": "Duce",
        "cityName": "new york",
        "department": "Content Production",
        "title": "Producer",
        "number": "212-981-8107",
        "seatlocation": "1323-12",
        "gender": "f"
    },
    {
        "fullname": "Joanna Durkalec",
        "firstName": "Joanna",
        "lastName": "Durkalec",
        "cityName": "new york",
        "department": "Creative",
        "title": "Senior Designer",
        "number": "212-981-8093",
        "seatlocation": "1420-59",
        "gender": "f"
    },
    {
        "fullname": "Sam Eisen",
        "firstName": "Sam",
        "lastName": "Eisen",
        "cityName": "new york",
        "department": "Creative",
        "title": "Copywriter",
        "number": "212-981-8071",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Paul Elicker",
        "firstName": "Paul",
        "lastName": "Elicker",
        "cityName": "new york",
        "department": "Creative",
        "title": "Senior Copywriter",
        "number": "212-981-7721",
        "seatlocation": "1415-21",
        "gender": "m"
    },
    {
        "fullname": "Kristen Eng",
        "firstName": "Kristen",
        "lastName": "Eng",
        "cityName": "new york",
        "department": "Studio",
        "title": "Studio Designer",
        "number": "212-651-8469",
        "seatlocation": "1322-49",
        "gender": "f"
    },
    {
        "fullname": "Heather English",
        "firstName": "Heather",
        "lastName": "English",
        "cityName": "new york",
        "department": "Creative",
        "title": "VP, Creative Director",
        "number": "212-981-7911",
        "seatlocation": "1415-19",
        "gender": "f"
    },
    {
        "fullname": "Tom Entrup",
        "firstName": "Tom",
        "lastName": "Entrup",
        "cityName": "new york",
        "department": "Finance",
        "title": "Partner, CFO",
        "number": "212-981-8097",
        "seatlocation": "1310-01",
        "gender": "m"
    },
    {
        "fullname": "Andrea Estrada",
        "firstName": "Andrea",
        "lastName": "Estrada",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-7810",
        "seatlocation": "1433-14",
        "gender": "f"
    },
    {
        "fullname": "Dana Fahey",
        "firstName": "Dana",
        "lastName": "Fahey",
        "cityName": "new york",
        "department": "Creative",
        "title": "Recruiter",
        "number": "",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Maged Faltas",
        "firstName": "Maged",
        "lastName": "Faltas",
        "cityName": "new york",
        "department": "Finance",
        "title": "Senior Financial Analyst",
        "number": "212-981-7659",
        "seatlocation": "1312-46",
        "gender": "m"
    },
    {
        "fullname": "Theresa Farina",
        "firstName": "Theresa",
        "lastName": "Farina",
        "cityName": "new york",
        "department": "Operations",
        "title": "VP, Director of Operations",
        "number": "212-981-7789",
        "seatlocation": "1301-09",
        "gender": "f"
    },
    {
        "fullname": "Amy Finucane",
        "firstName": "Amy",
        "lastName": "Finucane",
        "cityName": "new york",
        "department": "Art and Print Prod-NY",
        "title": "Proofreader",
        "number": "212-981-8087",
        "seatlocation": "1322-38",
        "gender": "f"
    },
    {
        "fullname": "Kevin Foley",
        "firstName": "Kevin",
        "lastName": "Foley",
        "cityName": "new york",
        "department": "Finance",
        "title": "Senior Accountant",
        "number": "212-981-7945",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Angel Fonseca",
        "firstName": "Angel",
        "lastName": "Fonseca",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Executive",
        "number": "212-981-7886",
        "seatlocation": "1433-17",
        "gender": "f"
    },
    {
        "fullname": "Aviva Friedman",
        "firstName": "Aviva",
        "lastName": "Friedman",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-7742",
        "seatlocation": "1433-29",
        "gender": "f"
    },
    {
        "fullname": "Marques Gartrell",
        "firstName": "Marques",
        "lastName": "Gartrell",
        "cityName": "new york",
        "department": "Creative",
        "title": "VP, Creative Director",
        "number": "212-981-7925",
        "seatlocation": "1415-20",
        "gender": "m"
    },
    {
        "fullname": "Troy Gary",
        "firstName": "Troy",
        "lastName": "Gary",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Digital Strategist",
        "number": "212-981-7724",
        "seatlocation": "1420-03",
        "gender": "m"
    },
    {
        "fullname": "Lauren Geisler",
        "firstName": "Lauren",
        "lastName": "Geisler",
        "cityName": "new york",
        "department": "Creative",
        "title": "Senior Art Director",
        "number": "212-981-7582",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Matthew George",
        "firstName": "Matthew",
        "lastName": "George",
        "cityName": "new york",
        "department": "Data Strategy",
        "title": "EVP, Director of Communications Planning",
        "number": "212-981-7814",
        "seatlocation": "1415-09",
        "gender": "m"
    },
    {
        "fullname": "Anthony Giustino",
        "firstName": "Anthony",
        "lastName": "Giustino",
        "cityName": "new york",
        "department": "Finance",
        "title": "Financial Analyst: Compensation & Resource Management",
        "number": "212-981-8106",
        "seatlocation": "1312-29",
        "gender": "m"
    },
    {
        "fullname": "Hector Gomez",
        "firstName": "Hector",
        "lastName": "Gomez",
        "cityName": "new york",
        "department": "Information Technology",
        "title": "Technical Support Specialist",
        "number": "212-651-8425",
        "seatlocation": "131T-04",
        "gender": "m"
    },
    {
        "fullname": "Reyes Gonzalez",
        "firstName": "Reyes",
        "lastName": "Gonzalez",
        "cityName": "new york",
        "department": "Information Technology",
        "title": "Technical Support Specialist",
        "number": "212-651-8404",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Jeff Good",
        "firstName": "Jeff",
        "lastName": "Good",
        "cityName": "new york",
        "department": "Creative",
        "title": "Associate Creative Director",
        "number": "212-981-7933",
        "seatlocation": "1415-09",
        "gender": "m"
    },
    {
        "fullname": "Christopher Gorka",
        "firstName": "Christopher",
        "lastName": "Gorka",
        "cityName": "new york",
        "department": "Information Technology",
        "title": "Architect, BI & Software",
        "number": "212-981-7688",
        "seatlocation": "1323-02",
        "gender": "m"
    },
    {
        "fullname": "Nicole Grabel",
        "firstName": "Nicole",
        "lastName": "Grabel",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Senior Strategist",
        "number": "212-981-7961",
        "seatlocation": "1312-02",
        "gender": "f"
    },
    {
        "fullname": "Dhobie Gracia",
        "firstName": "Dhobie",
        "lastName": "Gracia",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-7610",
        "seatlocation": "1433-15",
        "gender": "f"
    },
    {
        "fullname": "Erica Grau",
        "firstName": "Erica",
        "lastName": "Grau",
        "cityName": "new york",
        "department": "Executive New York",
        "title": "Partner, Chief Operating Officer",
        "number": "212-981-8091",
        "seatlocation": "1444-01",
        "gender": "f"
    },
    {
        "fullname": "Chris Green",
        "firstName": "Chris",
        "lastName": "Green",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Senior Planner",
        "number": "212-981-7935",
        "seatlocation": "1415-05",
        "gender": "m"
    },
    {
        "fullname": "David Green",
        "firstName": "David",
        "lastName": "Green",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Account Planner",
        "number": "212-981-7985",
        "seatlocation": "1433-18",
        "gender": "m"
    },
    {
        "fullname": "Cheryl Greene",
        "firstName": "Cheryl",
        "lastName": "Greene",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Strategy Consultant",
        "number": "212-981-8027",
        "seatlocation": 1417,
        "gender": "f"
    },
    {
        "fullname": "Marea Grossman",
        "firstName": "Marea",
        "lastName": "Grossman",
        "cityName": "new york",
        "department": "Project Management",
        "title": "VP, Associate Director, Project Management",
        "number": "212-981-7756",
        "seatlocation": "1433-27",
        "gender": "f"
    },
    {
        "fullname": "Jon Gruber",
        "firstName": "Jon",
        "lastName": "Gruber",
        "cityName": "new york",
        "department": "Creative",
        "title": "Copywriter",
        "number": "212-981-7953",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Rachel Gruber",
        "firstName": "Rachel",
        "lastName": "Gruber",
        "cityName": "new york",
        "department": "Social and Community",
        "title": "Senior Strategist, Digital",
        "number": "212-981-8046",
        "seatlocation": "1420-08",
        "gender": "f"
    },
    {
        "fullname": "Eric Grush",
        "firstName": "Eric",
        "lastName": "Grush",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "VP, Senior Editor",
        "number": "212-981-7848",
        "seatlocation": "1330-01",
        "gender": "m"
    },
    {
        "fullname": "Denise Guillet",
        "firstName": "Denise",
        "lastName": "Guillet",
        "cityName": "new york",
        "department": "Account Management",
        "title": "SVP, Group Account Director",
        "number": "212-981-7804",
        "seatlocation": "1325-02",
        "gender": "f"
    },
    {
        "fullname": "Juan Guzman",
        "firstName": "Juan",
        "lastName": "Guzman",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "Senior Motion Designer/Editor",
        "number": "212-981-7984",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Jun Ha",
        "firstName": "Jun",
        "lastName": "Ha",
        "cityName": "new york",
        "department": "Media",
        "title": "Assistant Media Planner",
        "number": "212-981-7559",
        "seatlocation": "1433-46",
        "gender": "m"
    },
    {
        "fullname": "Charles Hailey",
        "firstName": "Charles",
        "lastName": "Hailey",
        "cityName": "new york",
        "department": "Digital Creative",
        "title": "Quality Assurance Engineer",
        "number": "212-981-8078",
        "seatlocation": "1420-10",
        "gender": "m"
    },
    {
        "fullname": "John Haley",
        "firstName": "John",
        "lastName": "Haley",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "animator",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Alyson Hasenstab",
        "firstName": "Alyson",
        "lastName": "Hasenstab",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "Assistant Media Planner",
        "number": "212-981-7709",
        "seatlocation": "1312-16",
        "gender": "f"
    },
    {
        "fullname": "John Hatheway",
        "firstName": "John",
        "lastName": "Hatheway",
        "cityName": "new york",
        "department": "Digital Production",
        "title": "Digital Producer",
        "number": "212-981-7888",
        "seatlocation": "1322-27",
        "gender": "m"
    },
    {
        "fullname": "Ayana Hazeley",
        "firstName": "Ayana",
        "lastName": "Hazeley",
        "cityName": "new york",
        "department": "Administration",
        "title": "Executive Assistant",
        "number": "",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Kelsey Heard",
        "firstName": "Kelsey",
        "lastName": "Heard",
        "cityName": "new york",
        "department": "Creative",
        "title": "Art Director",
        "number": "212-981-7913",
        "seatlocation": "1420-48",
        "gender": "f"
    },
    {
        "fullname": "Ashley Heisner",
        "firstName": "Ashley",
        "lastName": "Heisner",
        "cityName": "new york",
        "department": "Project Management",
        "title": "Project Manager",
        "number": "212-981-8088",
        "seatlocation": "1420-39",
        "gender": "f"
    },
    {
        "fullname": "Tyler Helms",
        "firstName": "Tyler",
        "lastName": "Helms",
        "cityName": "new york",
        "department": "Account Management",
        "title": "EVP, Group Account Director",
        "number": "212-981-7712",
        "seatlocation": "1446-02",
        "gender": "m"
    },
    {
        "fullname": "Zackary Herpy",
        "firstName": "Zackary",
        "lastName": "Herpy",
        "cityName": "new york",
        "department": "Project Management",
        "title": "Project Manager",
        "number": "212-981-7856",
        "seatlocation": "1420-52",
        "gender": "m"
    },
    {
        "fullname": "Mindy Hoblack",
        "firstName": "Mindy",
        "lastName": "Hoblack",
        "cityName": "new york",
        "department": "Creative",
        "title": "Senior Copywriter",
        "number": "212-981-7967",
        "seatlocation": "1415-12",
        "gender": "f"
    },
    {
        "fullname": "Rebecca Hoffman",
        "firstName": "Rebecca",
        "lastName": "Hoffman",
        "cityName": "new york",
        "department": "Human Resources",
        "title": "Human Resources Coordinator",
        "number": "212-981-8111",
        "seatlocation": "1312*50",
        "gender": "f"
    },
    {
        "fullname": "Michael Huberman",
        "firstName": "Michael",
        "lastName": "Huberman",
        "cityName": "new york",
        "department": "Media",
        "title": "Media Research Analyst",
        "number": "212-981-7816",
        "seatlocation": "1312-25",
        "gender": "m"
    },
    {
        "fullname": "Lauren Hurwitz",
        "firstName": "Lauren",
        "lastName": "Hurwitz",
        "cityName": "new york",
        "department": "Digital Production",
        "title": "Senior Digital Producer",
        "number": "212-981-8039",
        "seatlocation": "1323-14",
        "gender": "f"
    },
    {
        "fullname": "Destiny Jackson",
        "firstName": "Destiny",
        "lastName": "Jackson",
        "cityName": "new york",
        "department": "Operations",
        "title": "Receptionist",
        "number": "212-981-8070",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Payal Jambusaria",
        "firstName": "Payal",
        "lastName": "Jambusaria",
        "cityName": "new york",
        "department": "Digital Creative",
        "title": "Software Engineer",
        "number": "212-981-7554",
        "seatlocation": "1420-17",
        "gender": "f"
    },
    {
        "fullname": "Taylor Jerome",
        "firstName": "Taylor",
        "lastName": "Jerome",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-8025",
        "seatlocation": "1433-35",
        "gender": "f"
    },
    {
        "fullname": "Danielle Johnsen-Karr",
        "firstName": "Danielle",
        "lastName": "Johnsen-Karr",
        "cityName": "new york",
        "department": "Social and Community",
        "title": "Social Strategy & Editorial Director",
        "number": "212-981-7977",
        "seatlocation": "1442-12",
        "gender": "f"
    },
    {
        "fullname": "Gregory Johnson",
        "firstName": "Gregory",
        "lastName": "Johnson",
        "cityName": "new york",
        "department": "Studio",
        "title": "QA Engineer",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Pete Johnson",
        "firstName": "Pete",
        "lastName": "Johnson",
        "cityName": "new york",
        "department": "Creative",
        "title": "EVP, Executive Creative Director",
        "number": "212-981-7747",
        "seatlocation": "1412-02",
        "gender": "m"
    },
    {
        "fullname": "Daniel Jones",
        "firstName": "Daniel",
        "lastName": "Jones",
        "cityName": "new york",
        "department": "Media",
        "title": "Senior Media Planner",
        "number": "212-981-7845",
        "seatlocation": "1433-42",
        "gender": "m"
    },
    {
        "fullname": "Derrick Joseph",
        "firstName": "Derrick",
        "lastName": "Joseph",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "AV Biller/Business Manager",
        "number": "212-981-7723",
        "seatlocation": "1322-21",
        "gender": "m"
    },
    {
        "fullname": "Julia Karlson",
        "firstName": "Julia",
        "lastName": "Karlson",
        "cityName": "new york",
        "department": "Finance",
        "title": "VP, Director Client Accounting",
        "number": "212-981-7918",
        "seatlocation": "1309-11",
        "gender": "f"
    },
    {
        "fullname": "Krish Karunanidhi",
        "firstName": "Krish",
        "lastName": "Karunanidhi",
        "cityName": "new york",
        "department": "Creative",
        "title": "Art Director",
        "number": "212-981-8084",
        "seatlocation": "1415-14",
        "gender": "m"
    },
    {
        "fullname": "Dan Kelleher",
        "firstName": "Dan",
        "lastName": "Kelleher",
        "cityName": "new york",
        "department": "Creative",
        "title": "Partner, Chief Creative Officer",
        "number": "212-981-7764",
        "seatlocation": "1418",
        "gender": "m"
    },
    {
        "fullname": "Danielle Kellner",
        "firstName": "Danielle",
        "lastName": "Kellner",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Executive",
        "number": "212-981-8102",
        "seatlocation": "1312-14",
        "gender": "f"
    },
    {
        "fullname": "Clara Kim",
        "firstName": "Clara",
        "lastName": "Kim",
        "cityName": "new york",
        "department": "Project Management",
        "title": "VP, Director Project Management",
        "number": "212-981-7980",
        "seatlocation": "1420-46",
        "gender": "f"
    },
    {
        "fullname": "Hyobee Kim",
        "firstName": "Hyobee",
        "lastName": "Kim",
        "cityName": "new york",
        "department": "Creative",
        "title": "Art Director",
        "number": "212-981-7644",
        "seatlocation": "1420-31",
        "gender": "f"
    },
    {
        "fullname": "Stephanie Kirnon",
        "firstName": "Stephanie",
        "lastName": "Kirnon",
        "cityName": "new york",
        "department": "Operations",
        "title": "Operations Coordinator",
        "number": "212-981-7912",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Jeff Knapp",
        "firstName": "Jeff",
        "lastName": "Knapp",
        "cityName": "new york",
        "department": "Studio",
        "title": "Proofreader",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Richard Kolopeaua",
        "firstName": "Richard",
        "lastName": "Kolopeaua",
        "cityName": "new york",
        "department": "Creative",
        "title": "VP, Creative Director",
        "number": "212-981-7746",
        "seatlocation": "1420-42",
        "gender": "m"
    },
    {
        "fullname": "Jeff Kopay",
        "firstName": "Jeff",
        "lastName": "Kopay",
        "cityName": "new york",
        "department": "Creative",
        "title": "Creative Director",
        "number": "212-981-8086",
        "seatlocation": "1420-44",
        "gender": "m"
    },
    {
        "fullname": "Isabella Kosal",
        "firstName": "Isabella",
        "lastName": "Kosal",
        "cityName": "new york",
        "department": "Media",
        "title": "Assistant Media Planner",
        "number": "212-981-7558",
        "seatlocation": "1433-47",
        "gender": "f"
    },
    {
        "fullname": "Lindsay Kramer",
        "firstName": "Lindsay",
        "lastName": "Kramer",
        "cityName": "new york",
        "department": "Business Development",
        "title": "Supervisor, Busines Development",
        "number": "212-981-7997",
        "seatlocation": "1442-11",
        "gender": "f"
    },
    {
        "fullname": "Julie Kravetz",
        "firstName": "Julie",
        "lastName": "Kravetz",
        "cityName": "new york",
        "department": "Strategy",
        "title": "SVP, Group Planning Director",
        "number": "212-98-7901",
        "seatlocation": "1447-01",
        "gender": "f"
    },
    {
        "fullname": "Jake Kuhnle",
        "firstName": "Jake",
        "lastName": "Kuhnle",
        "cityName": "new york",
        "department": "Finance",
        "title": "Timesheet Coordinator",
        "number": "212-981-7982",
        "seatlocation": "1312-51",
        "gender": "m"
    },
    {
        "fullname": "Amanda Lamoureux",
        "firstName": "Amanda",
        "lastName": "Lamoureux",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Director",
        "number": "212-981-7744",
        "seatlocation": "1442-09",
        "gender": "f"
    },
    {
        "fullname": "Chiyeung Lau",
        "firstName": "Chiyeung",
        "lastName": "Lau",
        "cityName": "new york",
        "department": "Creative",
        "title": "Copywriter",
        "number": "212-981-7874",
        "seatlocation": "1420-37",
        "gender": "m"
    },
    {
        "fullname": "April Lauderdale",
        "firstName": "April",
        "lastName": "Lauderdale",
        "cityName": "new york",
        "department": "Creative",
        "title": "Art Director",
        "number": "212-981-7917",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Justin Lee",
        "firstName": "Justin",
        "lastName": "Lee",
        "cityName": "new york",
        "department": "Creative",
        "title": "Digital Copywriter",
        "number": "212-981-8059",
        "seatlocation": "1415-13",
        "gender": "m"
    },
    {
        "fullname": "Sang Lee",
        "firstName": "Sang",
        "lastName": "Lee",
        "cityName": "new york",
        "department": "Creative",
        "title": "Digital Designer",
        "number": "212-981-7795",
        "seatlocation": "1420-65",
        "gender": "m"
    },
    {
        "fullname": "Gab Lentini",
        "firstName": "Gab",
        "lastName": "Lentini",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Executive",
        "number": "212-981-8103",
        "seatlocation": "1433-16",
        "gender": "f"
    },
    {
        "fullname": "Vonda LePage",
        "firstName": "Vonda",
        "lastName": "LePage",
        "cityName": "new york",
        "department": "Corporate Communications",
        "title": "EVP, Director of Corp Comm",
        "number": "212-981-7680",
        "seatlocation": "1413-01",
        "gender": "f"
    },
    {
        "fullname": "Jiaqi Li",
        "firstName": "Jiaqi",
        "lastName": "Li",
        "cityName": "new york",
        "department": "Data Strategy",
        "title": "VP, Data Strategist",
        "number": "212-981-7750",
        "seatlocation": "1442-13",
        "gender": "m"
    },
    {
        "fullname": "Kristen Little",
        "firstName": "Kristen",
        "lastName": "Little",
        "cityName": "new york",
        "department": "Media Buying",
        "title": "Local Buyer",
        "number": "212-981-7634",
        "seatlocation": "1312-30",
        "gender": "f"
    },
    {
        "fullname": "Leslie Long",
        "firstName": "Leslie",
        "lastName": "Long",
        "cityName": "new york",
        "department": "Human Resources",
        "title": "Recruiter",
        "number": "212-981-7562",
        "seatlocation": "1311-01",
        "gender": "f"
    },
    {
        "fullname": "Gabriella Loutfi",
        "firstName": "Gabriella",
        "lastName": "Loutfi",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "Editor",
        "number": "",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "John Lucas",
        "firstName": "John",
        "lastName": "Lucas",
        "cityName": "new york",
        "department": "Studio",
        "title": "Proofreader",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Jeanette Luis",
        "firstName": "Jeanette",
        "lastName": "Luis",
        "cityName": "new york",
        "department": "Art and Print Prod-NY",
        "title": "Executive Print Producer",
        "number": "212-981-7657",
        "seatlocation": "1323-20",
        "gender": "f"
    },
    {
        "fullname": "Derek Magesis",
        "firstName": "Derek",
        "lastName": "Magesis",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Director",
        "number": "212-981-8072",
        "seatlocation": "1442-08",
        "gender": "m"
    },
    {
        "fullname": "Jess Manganelli",
        "firstName": "Jess",
        "lastName": "Manganelli",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Director",
        "number": "212-981-7711",
        "seatlocation": "1433-08",
        "gender": "f"
    },
    {
        "fullname": "Halley Mangano",
        "firstName": "Halley",
        "lastName": "Mangano",
        "cityName": "new york",
        "department": "Content Production",
        "title": "Assistant Producer",
        "number": "212-981-8028",
        "seatlocation": "1322-33",
        "gender": "f"
    },
    {
        "fullname": "Sarah Manna",
        "firstName": "Sarah",
        "lastName": "Manna",
        "cityName": "new york",
        "department": "Art and Print Prod-NY",
        "title": "SVP, Director of Print and Art Production",
        "number": "212-981-8092",
        "seatlocation": "1323-21",
        "gender": "f"
    },
    {
        "fullname": "Miles Marden",
        "firstName": "Miles",
        "lastName": "Marden",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-7954",
        "seatlocation": "1312-14",
        "gender": "m"
    },
    {
        "fullname": "Helena Marklin",
        "firstName": "Helena",
        "lastName": "Marklin",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Executive",
        "number": "212-981-8040",
        "seatlocation": "1433-31",
        "gender": "f"
    },
    {
        "fullname": "Christina Martinez",
        "firstName": "Christina",
        "lastName": "Martinez",
        "cityName": "new york",
        "department": "Finance",
        "title": "Jr Staff Accountant",
        "number": "212-651-8484",
        "seatlocation": "1312-55",
        "gender": "f"
    },
    {
        "fullname": "Evelyn Martinez",
        "firstName": "Evelyn",
        "lastName": "Martinez",
        "cityName": "new york",
        "department": "Information Technology",
        "title": "Telecomm Manager",
        "number": "212-981-8110",
        "seatlocation": "1323-03",
        "gender": "f"
    },
    {
        "fullname": "Jimmy Martinoski",
        "firstName": "Jimmy",
        "lastName": "Martinoski",
        "cityName": "new york",
        "department": "Information Technology",
        "title": "Senior System Administrator",
        "number": "212-981-7785",
        "seatlocation": "131T-01",
        "gender": "m"
    },
    {
        "fullname": "Stephanie Matusewicz",
        "firstName": "Stephanie",
        "lastName": "Matusewicz",
        "cityName": "new york",
        "department": "Studio",
        "title": "Studio Artist",
        "number": "212-981-7861",
        "seatlocation": "1322-52",
        "gender": "f"
    },
    {
        "fullname": "Jayme Maultasch",
        "firstName": "Jayme",
        "lastName": "Maultasch",
        "cityName": "new york",
        "department": "Account Management",
        "title": "EVP, Group Account Director",
        "number": "212-981-7927",
        "seatlocation": "1445-01",
        "gender": "m"
    },
    {
        "fullname": "Alice Mazorra",
        "firstName": "Alice",
        "lastName": "Mazorra",
        "cityName": "new york",
        "department": "Studio",
        "title": "Senior Retoucher",
        "number": "212-981-7974",
        "seatlocation": "1316-01",
        "gender": "f"
    },
    {
        "fullname": "Tripp McCune",
        "firstName": "Tripp",
        "lastName": "McCune",
        "cityName": "new york",
        "department": "Information Technology",
        "title": "EVP, Chief Information Officer",
        "number": "212-981-7766",
        "seatlocation": "|1324-02",
        "gender": "m"
    },
    {
        "fullname": "Rachel McEuen",
        "firstName": "Rachel",
        "lastName": "McEuen",
        "cityName": "new york",
        "department": "Creative",
        "title": "Art Director",
        "number": "212-981-7839",
        "seatlocation": "1420-42",
        "gender": "f"
    },
    {
        "fullname": "Natalie McKaig",
        "firstName": "Natalie",
        "lastName": "McKaig",
        "cityName": "new york",
        "department": "Administration",
        "title": "Administrative Assistant",
        "number": "212-981-7574",
        "seatlocation": "1433-54",
        "gender": "f"
    },
    {
        "fullname": "Madalyn McLane",
        "firstName": "Madalyn",
        "lastName": "McLane",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Supervisor",
        "number": "212-981-7987",
        "seatlocation": "1312-11",
        "gender": "f"
    },
    {
        "fullname": "Brian McManus",
        "firstName": "Brian",
        "lastName": "McManus",
        "cityName": "new york",
        "department": "Finance",
        "title": "SVP, Contoller",
        "number": "212-981-7557",
        "seatlocation": "1306-02",
        "gender": "m"
    },
    {
        "fullname": "Rondell Meeks",
        "firstName": "Rondell",
        "lastName": "Meeks",
        "cityName": "new york",
        "department": "Studio",
        "title": "VP, Studio Services",
        "number": "212-981-7881",
        "seatlocation": "1320-01",
        "gender": "m"
    },
    {
        "fullname": "Rachel Mercer",
        "firstName": "Rachel",
        "lastName": "Mercer",
        "cityName": "new york",
        "department": "Strategy",
        "title": "SVP, Head of Digital Strategy and Invention",
        "number": "212-981-7553",
        "seatlocation": "1415-02",
        "gender": "f"
    },
    {
        "fullname": "Erin Metcalf",
        "firstName": "Erin",
        "lastName": "Metcalf",
        "cityName": "new york",
        "department": "Account Management",
        "title": "VP, Account Director",
        "number": "212-981-8044",
        "seatlocation": "1309-06",
        "gender": "f"
    },
    {
        "fullname": "Alex Miller",
        "firstName": "Alex",
        "lastName": "Miller",
        "cityName": "new york",
        "department": "Creative",
        "title": "Senior Interactive Designer",
        "number": "212-981-7683",
        "seatlocation": "1420-58",
        "gender": "m"
    },
    {
        "fullname": "Andrew Mixter",
        "firstName": "Andrew",
        "lastName": "Mixter",
        "cityName": "new york",
        "department": "Creative",
        "title": "Art Director",
        "number": "212-981-7561",
        "seatlocation": "1420-34",
        "gender": "m"
    },
    {
        "fullname": "Kristin Mommers",
        "firstName": "Kristin",
        "lastName": "Mommers",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Senior Account Planner",
        "number": "212-981-7899",
        "seatlocation": "1415-01",
        "gender": "f"
    },
    {
        "fullname": "Katherine Moncrief",
        "firstName": "Katherine",
        "lastName": "Moncrief",
        "cityName": "new york",
        "department": "Creative",
        "title": "EVP, Director of Talent",
        "number": "212-981-7575",
        "seatlocation": "1412-01",
        "gender": "f"
    },
    {
        "fullname": "Jeffrey Morgan",
        "firstName": "Jeffrey",
        "lastName": "Morgan",
        "cityName": "new york",
        "department": "Content Production",
        "title": "EP Steelhead",
        "number": "212-981-7992",
        "seatlocation": "1323-15",
        "gender": "m"
    },
    {
        "fullname": "Susan Mozdierz",
        "firstName": "Susan",
        "lastName": "Mozdierz",
        "cityName": "new york",
        "department": "Finance",
        "title": "VP, Asst. Dir. Of Client Accounting",
        "number": "212-981-7782",
        "seatlocation": "1309-15",
        "gender": "f"
    },
    {
        "fullname": "Mina Mukherjee",
        "firstName": "Mina",
        "lastName": "Mukherjee",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Executive",
        "number": "212-981-7788",
        "seatlocation": "1312-01",
        "gender": "f"
    },
    {
        "fullname": "Shreya Mukherjee",
        "firstName": "Shreya",
        "lastName": "Mukherjee",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Social Impact Practice Lead/SVP Group Planning Director",
        "number": "212-981-7588",
        "seatlocation": "1446-01",
        "gender": "f"
    },
    {
        "fullname": "Matt Mullen",
        "firstName": "Matt",
        "lastName": "Mullen",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "Editor",
        "number": "212-981-7827",
        "seatlocation": "1331 ( Edit 3 )",
        "gender": "m"
    },
    {
        "fullname": "Hiroki Murakami",
        "firstName": "Hiroki",
        "lastName": "Murakami",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Senior Strategist, Digital",
        "number": "212-981-7757",
        "seatlocation": "1420-04",
        "gender": "m"
    },
    {
        "fullname": "Daniel Murphy",
        "firstName": "Daniel",
        "lastName": "Murphy",
        "cityName": "new york",
        "department": "Digital Production",
        "title": "SVP, Director of Digital Production",
        "number": "212-981-7817",
        "seatlocation": "1321-01",
        "gender": "m"
    },
    {
        "fullname": "Luis Negron",
        "firstName": "Luis",
        "lastName": "Negron",
        "cityName": "new york",
        "department": "Studio",
        "title": "Sr Graphic Artist",
        "number": "212-981-7857",
        "seatlocation": "1322-51",
        "gender": "m"
    },
    {
        "fullname": "Michael Nicosia",
        "firstName": "Michael",
        "lastName": "Nicosia",
        "cityName": "new york",
        "department": "Digital Creative",
        "title": "Associate Director, Technology",
        "number": "212-981-7628",
        "seatlocation": "1420-07",
        "gender": "m"
    },
    {
        "fullname": "Orlando Nicot",
        "firstName": "Orlando",
        "lastName": "Nicot",
        "cityName": "new york",
        "department": "Executive New York",
        "title": "Executive Assistant",
        "number": "212-981-7780",
        "seatlocation": "1433-61",
        "gender": "m"
    },
    {
        "fullname": "Erin Nocito",
        "firstName": "Erin",
        "lastName": "Nocito",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "SVP, Group Media Director",
        "number": "212-981-7774",
        "seatlocation": "1442-15",
        "gender": "f"
    },
    {
        "fullname": "Trisha O’Connor",
        "firstName": "Trisha",
        "lastName": "O’Connor",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Director",
        "number": "212-981-7754",
        "seatlocation": "1433-07",
        "gender": "f"
    },
    {
        "fullname": "Joey Park",
        "firstName": "Joey",
        "lastName": "Park",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "animator",
        "number": "",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Jon Parker",
        "firstName": "Jon",
        "lastName": "Parker",
        "cityName": "new york",
        "department": "Creative",
        "title": "Copywriter",
        "number": "212-981-8108",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Able Parris",
        "firstName": "Able",
        "lastName": "Parris",
        "cityName": "new york",
        "department": "Creative",
        "title": "SVP, Group Creative Director",
        "number": "212-981-8009",
        "seatlocation": "1415-20",
        "gender": "m"
    },
    {
        "fullname": "Dharti Patel",
        "firstName": "Dharti",
        "lastName": "Patel",
        "cityName": "new york",
        "department": "Data Strategy",
        "title": "Data Strategist",
        "number": "212-981-7914",
        "seatlocation": "1433-58",
        "gender": "f"
    },
    {
        "fullname": "Scott Peebles",
        "firstName": "Scott",
        "lastName": "Peebles",
        "cityName": "new york",
        "department": "Studio",
        "title": "Proofreader",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Martha Pena",
        "firstName": "Martha",
        "lastName": "Pena",
        "cityName": "new york",
        "department": "Media",
        "title": "Paid Social Manager",
        "number": "212-981-7743",
        "seatlocation": "1312-14",
        "gender": "f"
    },
    {
        "fullname": "Joe Pernice",
        "firstName": "Joe",
        "lastName": "Pernice",
        "cityName": "new york",
        "department": "Content Production",
        "title": "Senior Producer/Content Director",
        "number": "212-271-6003",
        "seatlocation": "1322-26",
        "gender": "m"
    },
    {
        "fullname": "Sean Perrotta",
        "firstName": "Sean",
        "lastName": "Perrotta",
        "cityName": "new york",
        "department": "Operations",
        "title": "Mailroom Coordinator",
        "number": "212-981-7564",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Chelsea Peterson",
        "firstName": "Chelsea",
        "lastName": "Peterson",
        "cityName": "new york",
        "department": "Studio",
        "title": "Retoucher",
        "number": "212-981-8038",
        "seatlocation": "1316-02",
        "gender": "f"
    },
    {
        "fullname": "Lauren Pfahler",
        "firstName": "Lauren",
        "lastName": "Pfahler",
        "cityName": "new york",
        "department": "Digital Production",
        "title": "Digital Producer",
        "number": "212-981-7847",
        "seatlocation": "1322-28",
        "gender": "f"
    },
    {
        "fullname": "Danny Pincz",
        "firstName": "Danny",
        "lastName": "Pincz",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "Designer",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Oliver Plunkett",
        "firstName": "Oliver",
        "lastName": "Plunkett",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "Digital Media Supervisor",
        "number": "212-981-7631",
        "seatlocation": "1433-34",
        "gender": "m"
    },
    {
        "fullname": "Alex Porter",
        "firstName": "Alex",
        "lastName": "Porter",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-7946",
        "seatlocation": "1433-14",
        "gender": "m"
    },
    {
        "fullname": "Mick Potthast",
        "firstName": "Mick",
        "lastName": "Potthast",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Executive",
        "number": "212-981-7759",
        "seatlocation": "1433-24",
        "gender": "m"
    },
    {
        "fullname": "Adriana Poveda",
        "firstName": "Adriana",
        "lastName": "Poveda",
        "cityName": "new york",
        "department": "Social and Community",
        "title": "Associate Strategist, Digital",
        "number": "212-981-7775",
        "seatlocation": "1420-09",
        "gender": "f"
    },
    {
        "fullname": "Megan Prince",
        "firstName": "Megan",
        "lastName": "Prince",
        "cityName": "new york",
        "department": "Account Management",
        "title": "SVP, Account Director",
        "number": "212-981-7981",
        "seatlocation": "1442-03",
        "gender": "f"
    },
    {
        "fullname": "Juliet Pritner",
        "firstName": "Juliet",
        "lastName": "Pritner",
        "cityName": "new york",
        "department": "Studio",
        "title": "Proofreader",
        "number": "212-981-8019",
        "seatlocation": "1322-38",
        "gender": "f"
    },
    {
        "fullname": "Patricia Quaranta",
        "firstName": "Patricia",
        "lastName": "Quaranta",
        "cityName": "new york",
        "department": "Human Resources",
        "title": "VP, Director of Payroll & Benefits",
        "number": "212-981-7701",
        "seatlocation": "1420-27",
        "gender": "f"
    },
    {
        "fullname": "Sarah Rankin",
        "firstName": "Sarah",
        "lastName": "Rankin",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "SVP, Digital Group Media Director",
        "number": "212-981-8109",
        "seatlocation": "1442-14",
        "gender": "f"
    },
    {
        "fullname": "Linda Raskin",
        "firstName": "Linda",
        "lastName": "Raskin",
        "cityName": "new york",
        "department": "Art and Print Prod-NY",
        "title": "Proofreader",
        "number": "212-651-8496",
        "seatlocation": "1322-36",
        "gender": "f"
    },
    {
        "fullname": "Edgar Rasquinha",
        "firstName": "Edgar",
        "lastName": "Rasquinha",
        "cityName": "new york",
        "department": "Finance",
        "title": "Accounting Manager",
        "number": "212-651-8408",
        "seatlocation": "1309-13",
        "gender": "m"
    },
    {
        "fullname": "Alison Reilly",
        "firstName": "Alison",
        "lastName": "Reilly",
        "cityName": "new york",
        "department": "Creative",
        "title": "Digital Designer",
        "number": "212-981-7865",
        "seatlocation": "1420-55",
        "gender": "f"
    },
    {
        "fullname": "Ally Reis",
        "firstName": "Ally",
        "lastName": "Reis",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Executive",
        "number": "212-981-7771",
        "seatlocation": "1312-04",
        "gender": "f"
    },
    {
        "fullname": "Becky Reithmayr",
        "firstName": "Becky",
        "lastName": "Reithmayr",
        "cityName": "new york",
        "department": "Digital Production",
        "title": "Executive Digital Producer",
        "number": "212-271-6043",
        "seatlocation": "1322-35",
        "gender": "f"
    },
    {
        "fullname": "Christian Riley",
        "firstName": "Christian",
        "lastName": "Riley",
        "cityName": "new york",
        "department": "Operations",
        "title": "Receptionist",
        "number": "212-981-7969",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Kristen Rincavage",
        "firstName": "Kristen",
        "lastName": "Rincavage",
        "cityName": "new york",
        "department": "Account Management",
        "title": "SVP, Account Director",
        "number": "212-981-7870",
        "seatlocation": "1442-12",
        "gender": "f"
    },
    {
        "fullname": "Valentina Rosas",
        "firstName": "Valentina",
        "lastName": "Rosas",
        "cityName": "new york",
        "department": "Finance",
        "title": "Broadcast Biller",
        "number": "212-981-7661",
        "seatlocation": "1312-42",
        "gender": "f"
    },
    {
        "fullname": "April Rosenstock",
        "firstName": "April",
        "lastName": "Rosenstock",
        "cityName": "new york",
        "department": "Creative",
        "title": "Digital Designer",
        "number": "212-981-7627",
        "seatlocation": "1420-58",
        "gender": "f"
    },
    {
        "fullname": "Michelle Rowley",
        "firstName": "Michelle",
        "lastName": "Rowley",
        "cityName": "new york",
        "department": "Strategy",
        "title": "SVP, Group Planning Director",
        "number": "212-981-7784",
        "seatlocation": "1308-01",
        "gender": "f"
    },
    {
        "fullname": "Meg Ryan",
        "firstName": "Meg",
        "lastName": "Ryan",
        "cityName": "new york",
        "department": "Digital Production",
        "title": "Executive Digital Producer",
        "number": "212-981-7786",
        "seatlocation": "1323-21",
        "gender": "f"
    },
    {
        "fullname": "Marieme Sall",
        "firstName": "Marieme",
        "lastName": "Sall",
        "cityName": "new york",
        "department": "Art and Print Prod-NY",
        "title": "Associate Producer",
        "number": "212-981-7952",
        "seatlocation": "1322-32",
        "gender": "f"
    },
    {
        "fullname": "Joanne Scannello",
        "firstName": "Joanne",
        "lastName": "Scannello",
        "cityName": "new york",
        "department": "Creative",
        "title": "EVP, Group Creative Director",
        "number": "212-981-7738",
        "seatlocation": "1415-15",
        "gender": "f"
    },
    {
        "fullname": "Aaron Schillinger",
        "firstName": "Aaron",
        "lastName": "Schillinger",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "Editor",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Marlena Schmidt",
        "firstName": "Marlena",
        "lastName": "Schmidt",
        "cityName": "new york",
        "department": "Media Buying",
        "title": "VP, Local Buying Director",
        "number": "212-981-8120",
        "seatlocation": "1309-08",
        "gender": "f"
    },
    {
        "fullname": "Laura Schrager",
        "firstName": "Laura",
        "lastName": "Schrager",
        "cityName": "new york",
        "department": "Account Management",
        "title": "VP, Account Director",
        "number": "212-981-7878",
        "seatlocation": "1433-01",
        "gender": "f"
    },
    {
        "fullname": "Stacy Schwartz",
        "firstName": "Stacy",
        "lastName": "Schwartz",
        "cityName": "new york",
        "department": "Integrated Business Affairs",
        "title": "VP, Group Director",
        "number": "212-981-7959",
        "seatlocation": "1323-13",
        "gender": "f"
    },
    {
        "fullname": "Alla Seck",
        "firstName": "Alla",
        "lastName": "Seck",
        "cityName": "new york",
        "department": "Information Technology",
        "title": "Sr Network Administrator",
        "number": "212-981-7949",
        "seatlocation": "131T-03",
        "gender": "m"
    },
    {
        "fullname": "Madison Shaffer",
        "firstName": "Madison",
        "lastName": "Shaffer",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-7966",
        "seatlocation": "1433-07",
        "gender": "f"
    },
    {
        "fullname": "Breyden Sheldon",
        "firstName": "Breyden",
        "lastName": "Sheldon",
        "cityName": "new york",
        "department": "Creative",
        "title": "Copywriter",
        "number": "212-981-7751",
        "seatlocation": "1420-49",
        "gender": "m"
    },
    {
        "fullname": "Sang Min Shin",
        "firstName": "Sang",
        "lastName": "Min Shin",
        "cityName": "new york",
        "department": "Digital Creative",
        "title": "Creative Developer",
        "number": "212-981-7548",
        "seatlocation": "1420-26",
        "gender": "m"
    },
    {
        "fullname": "Damaris Sierra",
        "firstName": "Damaris",
        "lastName": "Sierra",
        "cityName": "new york",
        "department": "Media",
        "title": "Paid Social Assistant",
        "number": "212-981-7906",
        "seatlocation": "1312-35",
        "gender": "f"
    },
    {
        "fullname": "Pete Slife",
        "firstName": "Pete",
        "lastName": "Slife",
        "cityName": "new york",
        "department": "Steelhead – NY",
        "title": "Editor",
        "number": "",
        "seatlocation": "",
        "gender": "m"
    },
    {
        "fullname": "Matthew Smith",
        "firstName": "Matthew",
        "lastName": "Smith",
        "cityName": "new york",
        "department": "Data Strategy",
        "title": "Senior Data Strategist",
        "number": "212-981-7882",
        "seatlocation": "1433-57",
        "gender": "m"
    },
    {
        "fullname": "Shane Smith",
        "firstName": "Shane",
        "lastName": "Smith",
        "cityName": "new york",
        "department": "Content Production",
        "title": "Executive Content Producer",
        "number": "212-981-8096",
        "seatlocation": "1323-18",
        "gender": "m"
    },
    {
        "fullname": "Jessica Spar",
        "firstName": "Jessica",
        "lastName": "Spar",
        "cityName": "new york",
        "department": "Media",
        "title": "Associate Director, Paid Social",
        "number": "212-981-7556",
        "seatlocation": "1312-13",
        "gender": "f"
    },
    {
        "fullname": "Alexander Studer",
        "firstName": "Alexander",
        "lastName": "Studer",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Assistant Account Executive",
        "number": "212-981-7654",
        "seatlocation": "1312-06",
        "gender": "m"
    },
    {
        "fullname": "Tara Suess",
        "firstName": "Tara",
        "lastName": "Suess",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "Integrated Media Planner",
        "number": "212-981-7745",
        "seatlocation": "1433-44",
        "gender": "f"
    },
    {
        "fullname": "Chad Sullivan",
        "firstName": "Chad",
        "lastName": "Sullivan",
        "cityName": "new york",
        "department": "Media Planning",
        "title": "Digital Media Planner",
        "number": "212-981-8095",
        "seatlocation": "1433-45",
        "gender": "m"
    },
    {
        "fullname": "Brian Szabo",
        "firstName": "Brian",
        "lastName": "Szabo",
        "cityName": "new york",
        "department": "Social and Community",
        "title": "Brand Publishing & Community Manager",
        "number": "212-981-8033",
        "seatlocation": "1420-10",
        "gender": "m"
    },
    {
        "fullname": "Rakesh Talwar",
        "firstName": "Rakesh",
        "lastName": "Talwar",
        "cityName": "new york",
        "department": "Account Management",
        "title": "SVP, Account Director",
        "number": "212-981-7598",
        "seatlocation": "1442-03",
        "gender": "m"
    },
    {
        "fullname": "Maria Taris",
        "firstName": "Maria",
        "lastName": "Taris",
        "cityName": "new york",
        "department": "Integrated Business Affairs",
        "title": "SVP, Director of Business Affairs",
        "number": "212-981-7849",
        "seatlocation": "1323-12",
        "gender": "f"
    },
    {
        "fullname": "Vinney Tecchio",
        "firstName": "Vinney",
        "lastName": "Tecchio",
        "cityName": "new york",
        "department": "Creative",
        "title": "Creative Director",
        "number": "212-981-7566",
        "seatlocation": "1433-06",
        "gender": "m"
    },
    {
        "fullname": "Oliver Torres",
        "firstName": "Oliver",
        "lastName": "Torres",
        "cityName": "new york",
        "department": "Finance",
        "title": "Financial Analyst",
        "number": "212-981-7576",
        "seatlocation": "1312-37",
        "gender": "m"
    },
    {
        "fullname": "Mary Toto",
        "firstName": "Mary",
        "lastName": "Toto",
        "cityName": "new york",
        "department": "Digital Production",
        "title": "Executive Producer",
        "number": "212-981-7585",
        "seatlocation": "1323-07",
        "gender": "f"
    },
    {
        "fullname": "Richard VanSteenburgh",
        "firstName": "Richard",
        "lastName": "VanSteenburgh",
        "cityName": "new york",
        "department": "Data Strategy",
        "title": "EVP, Director of Data Analytics",
        "number": "212-981-7910",
        "seatlocation": "1415-11",
        "gender": "m"
    },
    {
        "fullname": "Washington Vazquez",
        "firstName": "Washington",
        "lastName": "Vazquez",
        "cityName": "new york",
        "department": "Finance",
        "title": "Sr Accountant",
        "number": "212-981-7838",
        "seatlocation": "1312-54",
        "gender": "m"
    },
    {
        "fullname": "Jeffrey Vinick",
        "firstName": "Jeffrey",
        "lastName": "Vinick",
        "cityName": "new york",
        "department": "Creative",
        "title": "EVP, Executive Creative Director",
        "number": "212-981-8061",
        "seatlocation": "1415-17",
        "gender": "m"
    },
    {
        "fullname": "Mai Vu",
        "firstName": "Mai",
        "lastName": "Vu",
        "cityName": "new york",
        "department": "Strategy",
        "title": "VP, Planning Director",
        "number": "212-981-7998",
        "seatlocation": "1442-04",
        "gender": "f"
    },
    {
        "fullname": "James Wallace",
        "firstName": "James",
        "lastName": "Wallace",
        "cityName": "new york",
        "department": "Finance",
        "title": "Senior Financial Analyst",
        "number": "212-981-7616",
        "seatlocation": "1312-08",
        "gender": "m"
    },
    {
        "fullname": "Ace Wang",
        "firstName": "Ace",
        "lastName": "Wang",
        "cityName": "new york",
        "department": "Strategy",
        "title": "Senior Strategist, Digital",
        "number": "212-651-8477",
        "seatlocation": "1420-02",
        "gender": "f"
    },
    {
        "fullname": "Craig Ward",
        "firstName": "Craig",
        "lastName": "Ward",
        "cityName": "new york",
        "department": "Creative",
        "title": "SVP, Head of Design",
        "number": "212-981-8105",
        "seatlocation": "1414-01",
        "gender": "m"
    },
    {
        "fullname": "Dennis Warlick",
        "firstName": "Dennis",
        "lastName": "Warlick",
        "cityName": "new york",
        "department": "Information Technology",
        "title": "VP, Strategic Technologies",
        "number": "212-981-8118",
        "seatlocation": "1323-01",
        "gender": "m"
    },
    {
        "fullname": "AJ Warren",
        "firstName": "AJ",
        "lastName": "Warren",
        "cityName": "new york",
        "department": "Creative",
        "title": "Senior Copywriter",
        "number": "212-981-7696",
        "seatlocation": "1415-20",
        "gender": "m"
    },
    {
        "fullname": "Lori Anne Watkins",
        "firstName": "Lori",
        "lastName": "Anne Watkins",
        "cityName": "new york",
        "department": "Media Buying",
        "title": "Network Operations Manager",
        "number": "212-981-7960",
        "seatlocation": "",
        "gender": "f"
    },
    {
        "fullname": "Danielle Weiner",
        "firstName": "Danielle",
        "lastName": "Weiner",
        "cityName": "new york",
        "department": "Account Management",
        "title": "Account Supervisor",
        "number": "212-981-7926",
        "seatlocation": "1433-37",
        "gender": "f"
    },
    {
        "fullname": "Vinnette Willie-Bygrave",
        "firstName": "Vinnette",
        "lastName": "Willie-Bygrave",
        "cityName": "new york",
        "department": "Finance",
        "title": "T & E Coordinator",
        "number": "212-981-8094",
        "seatlocation": "1312-45",
        "gender": "f"
    },
    {
        "fullname": "Denise Wilson",
        "firstName": "Denise",
        "lastName": "Wilson",
        "cityName": "new york",
        "department": "Finance",
        "title": "Accounts Payable Supervisor",
        "number": "212-981-7787",
        "seatlocation": "1312-56",
        "gender": "f"
    },
    {
        "fullname": "Emily Yao",
        "firstName": "Emily",
        "lastName": "Yao",
        "cityName": "new york",
        "department": "Media",
        "title": "Associate Media Director",
        "number": "212-981-7972",
        "seatlocation": "1433-41",
        "gender": "f"
    },
    {
        "fullname": "Davis Yee",
        "firstName": "Davis",
        "lastName": "Yee",
        "cityName": "new york",
        "department": "Studio",
        "title": "Studio Manager",
        "number": "212-981-7571",
        "seatlocation": "1322-45",
        "gender": "m"
    },
    {
        "fullname": "Eden Zugel",
        "firstName": "Eden",
        "lastName": "Zugel",
        "cityName": "new york",
        "department": "Operations",
        "title": "Operations Manager",
        "number": "212-981-7617",
        "seatlocation": "1301-08",
        "gender": "f"
    }
];

//======================================================================================================
//TODO: Replace these text strings to edit the welcome and help messages
//======================================================================================================

var skillName = "Deutscher Lookup. ";

//This is the welcome message for when a user starts the skill without a specific intent.
var WELCOME_MESSAGE = "Welcome to " + skillName + "Learn about Deutschers and their info. For example, " + getGenericHelpMessage(data);

//This is the message a user will hear when they ask Alexa for help in your skill.
var HELP_MESSAGE = "I can help you find Deutschers and their info. ";

//This is the message a user will hear when they begin a new search
var NEW_SEARCH_MESSAGE = getGenericHelpMessage(data);

//This is the message a user will hear when they ask Alexa for help while in the SEARCH state
var SEARCH_STATE_HELP_MESSAGE = getGenericHelpMessage(data);

var DESCRIPTION_STATE_HELP_MESSAGE = "Here are some things you can say: Tell me more, or give me his or her contact info";

var MULTIPLE_RESULTS_STATE_HELP_MESSAGE = "Sorry, please say the first and last name of the Deutscher you'd like to learn more about";

// This is the message use when the decides to end the search
var SHUTDOWN_MESSAGE = "Ok.";

//This is the message a user will hear when they try to cancel or stop the skill.
var EXIT_SKILL_MESSAGE = "Ok.";

// =====================================================================================================
// ------------------------------ Section 2. Skill Code - Intent Handlers  -----------------------------
// =====================================================================================================
// CAUTION: Editing anything below this line might break your skill.
//======================================================================================================

var states = {
    SEARCHMODE: "_SEARCHMODE",
    DESCRIPTION: "_DESCRIPTION",
    MULTIPLE_RESULTS: "_MULTIPLE_RESULTS"
};

const newSessionHandlers = {
    "LaunchRequest": function () {
        this.handler.state = states.SEARCHMODE;
        this.emit(":ask", WELCOME_MESSAGE, getGenericHelpMessage(data));
    },
    "SearchByNameIntent": function () {
        console.log("SEARCH INTENT");
        this.handler.state = states.SEARCHMODE;
        this.emitWithState("SearchByNameIntent");
    },
    "TellMeMoreIntent": function () {
        this.handler.state = states.SEARCHMODE;
        this.emit(":ask", WELCOME_MESSAGE, getGenericHelpMessage(data));
    },
    "TellMeThisIntent": function () {
        this.handler.state = states.SEARCHMODE;
        this.emitWithState("SearchByNameIntent");
    },
    "SearchByInfoTypeIntent": function () {
        this.handler.state = states.SEARCHMODE;
        this.emitWithState("SearchByInfoTypeIntent");
    },
    "AMAZON.YesIntent": function () {
        this.emit(":ask", getGenericHelpMessage(data), getGenericHelpMessage(data));
    },
    "AMAZON.NoIntent": function () {
        this.emit(":tell", SHUTDOWN_MESSAGE);
    },
    "AMAZON.RepeatIntent": function () {
        this.emit(":ask", HELP_MESSAGE, getGenericHelpMessage(data));
    },
    "AMAZON.StopIntent": function () {
        this.emit(":tell", EXIT_SKILL_MESSAGE);
    },
    "AMAZON.CancelIntent": function () {
        this.emit(":tell", EXIT_SKILL_MESSAGE);
    },
    "AMAZON.StartOverIntent": function () {
        this.handler.state = states.SEARCHMODE;
        var output = "Ok, starting over." + getGenericHelpMessage(data);
        this.emit(":ask", output, output);
    },
    "AMAZON.HelpIntent": function () {
        this.emit(":ask", HELP_MESSAGE + getGenericHelpMessage(data), getGenericHelpMessage(data));
    },
    "SessionEndedRequest": function () {
        this.emit("AMAZON.StopIntent");
    },
    "Unhandled": function () {
        this.handler.state = states.SEARCHMODE;
        this.emitWithState("SearchByNameIntent");
    }
};
var startSearchHandlers = Alexa.CreateStateHandler(states.SEARCHMODE, {
    "AMAZON.YesIntent": function () {
        this.emit(":ask", NEW_SEARCH_MESSAGE, NEW_SEARCH_MESSAGE);
    },
    "AMAZON.NoIntent": function () {
        this.emit(":tell", SHUTDOWN_MESSAGE);
    },
    "AMAZON.RepeatIntent": function () {
        var output;
        if (this.attributes.lastSearch) {
            output = this.attributes.lastSearch.lastSpeech;
            console.log("repeating last speech");
        } else {
            output = getGenericHelpMessage(data);
            console.log("no last speech availble. outputting standard help message.");
        }
        this.emit(":ask", output, output);
    },
    "SearchByNameIntent": function () {
        searchByNameIntentHandler.call(this);
    },
    "SearchByCityIntent": function () {
        searchByCityIntentHandler.call(this);
    },
    "SearchByInfoTypeIntent": function () {
        searchByInfoTypeIntentHandler.call(this);
    },
    "TellMeThisIntent": function () {
        this.handler.state = states.DESCRIPTION;
        this.emitWithState("TellMeThisIntent");
    },
    "TellMeMoreIntent": function () {
        this.handler.state = states.DESCRIPTION;
        this.emitWithState("TellMeMoreIntent");
    },
    "AMAZON.HelpIntent": function () {
        this.emit(":ask", getGenericHelpMessage(data), getGenericHelpMessage(data));
    },
    "AMAZON.StopIntent": function () {
        this.emit(":tell", EXIT_SKILL_MESSAGE);
    },
    "AMAZON.CancelIntent": function () {
        this.emit(":tell", EXIT_SKILL_MESSAGE);
    },
    "AMAZON.StartOverIntent": function () {
        this.handler.state = states.SEARCHMODE;
        var output = "Ok, starting over." + getGenericHelpMessage(data);
        this.emit(":ask", output, output);
    },
    "SessionEndedRequest": function () {
        this.emit("AMAZON.StopIntent");
    },
    "Unhandled": function () {
        console.log("Unhandled intent in startSearchHandlers");
        this.emit(":ask", SEARCH_STATE_HELP_MESSAGE, SEARCH_STATE_HELP_MESSAGE);
    }
});
var multipleSearchResultsHandlers = Alexa.CreateStateHandler(states.MULTIPLE_RESULTS, {

    "AMAZON.StartOverIntent": function () {
        this.handler.state = states.SEARCHMODE;
        var output = "Ok, starting over." + getGenericHelpMessage(data);
        this.emit(":ask", output, output);
    },
    "AMAZON.YesIntent": function () {
        var output = "Hmm. I think you said - yes, but can you please say the name of the Deutscher you'd like to learn more about?";
        this.emit(":ask", output, output);
    },
    "AMAZON.NoIntent": function () {
        this.emit(":tell", SHUTDOWN_MESSAGE);
    },
    "AMAZON.RepeatIntent": function () {
        this.emit(":ask", this.attributes.lastSearch.lastSpeech, this.attributes.lastSearch.lastSpeech);
    },
    "SearchByNameIntent": function () {
        var slots = this.event.request.intent.slots;
        var firstName = isSlotValid(this.event.request, "firstName");
        var lastName = isSlotValid(this.event.request, "lastName");
        var cityName = isSlotValid(this.event.request, "cityName");
        var infoType = isSlotValid(this.event.request, "infoType");
       
        firstName = firstName.toLowerCase(); 
        lastName = lastName.toLowerCase(); 
      
        console.log("firstName:" + firstName);
        console.log("firstName:" + lastName);
        console.log("firstName:" + cityName);
        console.log("firstName:" + infoType);
        console.log("Intent Name:" + this.event.request.intent.name);

        var canSearch = figureOutWhichSlotToSearchBy(firstName, lastName, cityName);
        console.log("Multiple results found. canSearch is set to = " + canSearch);
        var speechOutput;

        if (canSearch)
            var searchQuery = slots[canSearch].value;
        var searchResults = searchDatabase(this.attributes.lastSearch.results, searchQuery, canSearch);
        var lastSearch;
        var output;

        if (searchResults.count > 1) { //multiple results found again
            console.log("multiple results were found again");
            this.handler.state = states.MULTIPLE_RESULTS;
            output = this.attributes.lastSearch.lastSpeech;
            this.emit(":ask", output);
        } else if (searchResults.count == 1) { //one result found
            this.attributes.lastSearch = searchResults;
            lastSearch = this.attributes.lastSearch;
            this.handler.state = states.DESCRIPTION;
            output = generateSearchResultsMessage(searchQuery, searchResults.results);
            this.attributes.lastSearch.lastSpeech = output;
            this.emit(":ask", output);

        } else { //no match found
            lastSearch = this.attributes.lastSearch;
            var listOfPeopleFound = loopThroughArrayOfObjects(lastSearch.results);
            speechOutput = MULTIPLE_RESULTS_STATE_HELP_MESSAGE + ", " + listOfPeopleFound;
            this.emit(":ask", speechOutput);
        }
    },
    "SearchByCityIntent": function () {
        this.handler.state = states.SEARCHMODE;
        this.emitWithState("SearchByCityIntent");
    },
    "AMAZON.HelpIntent": function () {
        this.emit(":ask", MULTIPLE_RESULTS_STATE_HELP_MESSAGE, MULTIPLE_RESULTS_STATE_HELP_MESSAGE);
    },
    "AMAZON.StopIntent": function () {
        this.emit(":tell", EXIT_SKILL_MESSAGE);
    },
    "AMAZON.CancelIntent": function () {
        this.emit(":tell", EXIT_SKILL_MESSAGE);
    },
    "SessionEndedRequest": function () {
        this.emit("AMAZON.StopIntent");
    },
    "Unhandled": function () {
        console.log("Unhandled intent in multipleSearchResultsHandlers");
        this.emit(":ask", MULTIPLE_RESULTS_STATE_HELP_MESSAGE, MULTIPLE_RESULTS_STATE_HELP_MESSAGE);
    }
});
var descriptionHandlers = Alexa.CreateStateHandler(states.DESCRIPTION, {
    "TellMeMoreIntent": function () {
        var person;
        var speechOutput;
        var repromptSpeech;
        var cardContent;

        if (this.attributes.lastSearch) {
            person = this.attributes.lastSearch.results[0];
            cardContent = generateCard(person); //calling the helper function to generate the card content that will be sent to the Alexa app.
            speechOutput = generateTellMeMoreMessage(person);
            repromptSpeech = "Would you like to find another Deutscher? Say yes or no";

            console.log("the contact you're trying to find more info about is " + person.firstName);
            this.handler.state = states.SEARCHMODE;
            this.attributes.lastSearch.lastSpeech = speechOutput;
            this.emit(":askWithCard", speechOutput, repromptSpeech, cardContent.title, cardContent.body, cardContent.image);
        } else {
            speechOutput = getGenericHelpMessage(data);
            repromptSpeech = getGenericHelpMessage(data);
            this.handler.state = states.SEARCHMODE;
            this.emit(":ask", speechOutput, repromptSpeech);
        }
    },
    "TellMeThisIntent": function () {
        var slots = this.event.request.intent.slots;
        var person = this.attributes.lastSearch.results[0];
        var infoType = isSlotValid(this.event.request, "infoType");
        var speechOutput;
        var repromptSpeech;
        var cardContent;

        console.log(isInfoTypeValid("title"));

        if (this.attributes.lastSearch && isInfoTypeValid(infoType)) {
            person = this.attributes.lastSearch.results[0];
            cardContent = generateCard(person);
            speechOutput = generateSpecificInfoMessage(slots, person);
            repromptSpeech = "Would you like to find another Deutscher? Say yes or no";
            this.handler.state = states.SEARCHMODE;
            this.attributes.lastSearch.lastSpeech = speechOutput;
            this.emit(":askWithCard", speechOutput, repromptSpeech, cardContent.title, cardContent.body, cardContent.image);
        } else {
            //not a valid slot. no card needs to be set up. respond with simply a voice response.
            speechOutput = generateSearchHelpMessage(person.gender);
            repromptSpeech = "You can ask me - what's " + genderize("his-her", person.gender) + " department, phone number, seat location or give me " + genderize("his-her", person.gender) + " title";
            this.attributes.lastSearch.lastSpeech = speechOutput;
            this.handler.state = states.SEARCHMODE;
            this.emit(":ask", speechOutput, repromptSpeech);
        }
    },
    "SearchByNameIntent": function () {
        searchByNameIntentHandler.call(this);
    },
    "SearchByCityIntent": function () {
        searchByCityIntentHandler.call(this);
    },
    "AMAZON.HelpIntent": function () {
        var person = this.attributes.lastSearch.results[0];
        this.emit(":ask", generateNextPromptMessage(person, "current"), generateNextPromptMessage(person, "current"));
    },
    "AMAZON.StopIntent": function () {
        this.emit(":tell", EXIT_SKILL_MESSAGE);
    },
    "AMAZON.CancelIntent": function () {
        this.emit(":tell", EXIT_SKILL_MESSAGE);
    },
    "AMAZON.NoIntent": function () {
        this.emit(":tell", SHUTDOWN_MESSAGE);
    },
    "AMAZON.YesIntent": function () {
        this.emit("TellMeMoreIntent");
    },
    "AMAZON.RepeatIntent": function () {
        this.emit(":ask", this.attributes.lastSearch.lastSpeech, this.attributes.lastSearch.lastSpeech);
    },
    "AMAZON.StartOverIntent": function () {
        this.handler.state = states.SEARCHMODE;
        var output = "Ok, starting over." + getGenericHelpMessage(data);
        this.emit(":ask", output, output);
    },
    "SessionEndedRequest": function () {
        this.emit("AMAZON.StopIntent");
    },
    "Unhandled": function () {
        var person = this.attributes.lastSearch.results[0];
        console.log("Unhandled intent in DESCRIPTION state handler");
        this.emit(":ask", "Sorry, I don't know that" + generateNextPromptMessage(person, "general"), "Sorry, I don't know that" + generateNextPromptMessage(person, "general"));
    }
});

// ------------------------- END of Intent Handlers  ---------------------------------

function searchDatabase(dataset, searchQuery, searchType) {
    var matchFound = false;
    var results = [];

    //beginning search
    for (var i = 0; i < dataset.length; i++) {
        if (sanitizeSearchQuery(searchQuery) == dataset[i][searchType]) {
            results.push(dataset[i]);
            matchFound = true;
        }
        if ((i == dataset.length - 1) && (matchFound == false)) {
            //this means that we are on the last record, and no match was found
            matchFound = false;
            console.log("no match was found using " + searchType);
            //if more than searchable items were provided, set searchType to the next item, and set i=0
            //ideally you want to start search with lastName, then firstname, and then cityName
        }
    }
    return {
        count: results.length,
        results: results
    };
}

function figureOutWhichSlotToSearchBy(firstName, lastName, cityName) {
    if (lastName) {
        console.log("search by lastName");
        return "lastName";
    } else if (!lastName && firstName) {
        console.log("search by firstName");
        return "firstName";
    } else if (!lastName && !firstName && cityName) {
        console.log("search by cityName");
        return "cityName";
    } else {
        console.log("no valid slot provided. can't search.");
        return false;
    }
}


function searchByNameIntentHandler() {
    var firstName = isSlotValid(this.event.request, "firstName");
    var lastName = isSlotValid(this.event.request, "lastName");
    var cityName = isSlotValid(this.event.request, "cityName");
    var infoType = isSlotValid(this.event.request, "infoType");

    var canSearch = figureOutWhichSlotToSearchBy(firstName, lastName, cityName);
    console.log("canSearch is set to = " + canSearch);

    if (canSearch) {
        var searchQuery = this.event.request.intent.slots[canSearch].value;
        var searchResults = searchDatabase(data, searchQuery, canSearch);

        //saving lastSearch results to the current session
        var lastSearch = this.attributes.lastSearch = searchResults;
        var output;

        //saving last intent to session attributes
        this.attributes.lastSearch.lastIntent = "SearchByNameIntent";

        if (searchResults.count > 1) { //multiple results found
            console.log("Search complete. Multiple results were found");
            var listOfPeopleFound = loopThroughArrayOfObjects(lastSearch.results);
            output = generateSearchResultsMessage(searchQuery, searchResults.results) + listOfPeopleFound + ". Who would you like to learn more about?";
            this.handler.state = states.MULTIPLE_RESULTS; // change state to MULTIPLE_RESULTS
            this.attributes.lastSearch.lastSpeech = output;
            this.emit(":ask", output);
        } else if (searchResults.count == 1) { //one result found
            this.handler.state = states.DESCRIPTION; // change state to description
            console.log("one match was found");
            if (infoType) {
                //if a specific infoType was requested, redirect to specificInfoIntent
                console.log("infoType was provided as well");
                this.emitWithState("TellMeThisIntent");
            } else {
                console.log("no infoType was provided.");
                output = generateSearchResultsMessage(searchQuery, searchResults.results);
                this.attributes.lastSearch.lastSpeech = output;
                this.emit(":ask", output);
            }
        } else { //no match found
            console.log("no match found");
            console.log("searchQuery was  = " + searchQuery);
            console.log("searchResults.results was  = " + searchResults);
            output = generateSearchResultsMessage(searchQuery, searchResults.results);
            this.attributes.lastSearch.lastSpeech = output;
            // this.emit(":ask", generateSearchResultsMessage(searchQuery,searchResults.results));
            this.emit(":ask", output);
        }
    } else {
        console.log("no searchable slot was provided");
        console.log("searchQuery was  = " + searchQuery);
        console.log("searchResults.results was  = " + searchResults);

        this.emit(":ask", generateSearchResultsMessage(searchQuery, false));
    }
}

function searchByCityIntentHandler() {
    var slots = this.event.request.intent.slots;
    var cityName = isSlotValid(this.event.request, "cityName");

    if (cityName) {
        var searchQuery = slots.cityName.value;
        console.log("will begin search with  " + slots.cityName.value + " in cityName");
        var searchResults = searchDatabase(data, searchQuery, "cityName");

        //saving lastSearch results to the current session
        var lastSearch = this.attributes.lastSearch = searchResults;
        var output;

        //saving last intent to session attributes
        this.attributes.lastSearch.lastIntent = "SearchByNameIntent";

        if (searchResults.count > 1) { //multiple results found
            console.log("Search completed by city. Multiple results were found");
            var listOfPeopleFound = loopThroughArrayOfObjects(lastSearch.results);
            output = generateSearchResultsMessage(searchQuery, searchResults.results) + listOfPeopleFound + ". Who would you like to learn more about?";
            this.handler.state = states.MULTIPLE_RESULTS; // change state to MULTIPLE_RESULTS
            this.attributes.lastSearch.lastSpeech = output;
            this.emit(":ask", output);
        } else if (searchResults.count == 1) { //one result found
            console.log("one match found");
            this.handler.state = states.DESCRIPTION; // change state to description
            output = generateSearchResultsMessage(searchQuery, searchResults.results);
            this.attributes.lastSearch.lastSpeech = output;
            // this.emit(":ask", generateSearchResultsMessage(searchQuery,searchResults.results));
            this.emit(":ask", output);

        } else { //no match found
            console.log("no match found");
            console.log("searchQuery was  = " + searchQuery);
            console.log("searchResults.results was  = " + searchResults);
            output = generateSearchResultsMessage(searchQuery, searchResults.results);
            this.attributes.lastSearch.lastSpeech = output;
            // this.emit(":ask", generateSearchResultsMessage(searchQuery,searchResults.results));
            this.emit(":ask", output);

        }
    } else {
        console.log("no searchable slot was provided");
        console.log("searchQuery was  = " + searchQuery);
        console.log("searchResults.results was  = " + searchResults);

        this.emit(":ask", generateSearchResultsMessage(searchQuery, false));
    }
}

function searchByInfoTypeIntentHandler() {
    var slots = this.event.request.intent.slots;
    var firstName = isSlotValid(this.event.request, "firstName");
    var lastName = isSlotValid(this.event.request, "lastName");
    var cityName = isSlotValid(this.event.request, "cityName");
    var infoType = isSlotValid(this.event.request, "infoType");

    var canSearch = figureOutWhichSlotToSearchBy(firstName, lastName, cityName);
    console.log("canSearch is set to = " + canSearch);

    if (canSearch) {
        var searchQuery = slots[canSearch].value;
        var searchResults = searchDatabase(data, searchQuery, canSearch);

        //saving lastSearch results to the current session
        var lastSearch = this.attributes.lastSearch = searchResults;
        var output;

        //saving last intent to session attributes
        this.attributes.lastSearch.lastIntent = "SearchByNameIntent";

        if (searchResults.count > 1) { //multiple results found
            console.log("multiple results were found");
            var listOfPeopleFound = loopThroughArrayOfObjects(lastSearch.results);
            output = generateSearchResultsMessage(searchQuery, searchResults.results) + listOfPeopleFound + ". Who would you like to learn more about?";
            this.handler.state = states.MULTIPLE_RESULTS; // change state to MULTIPLE_RESULTS
            this.attributes.lastSearch.lastSpeech = output;
            this.emit(":ask", output);
        } else if (searchResults.count == 1) { //one result found
            this.handler.state = states.DESCRIPTION; // change state to description
            console.log("one match was found");
            if (infoType) {
                //if a specific infoType was requested, redirect to specificInfoIntent
                console.log("infoType was provided as well");
                var person = this.attributes.lastSearch.results[0];
                var cardContent = generateCard(person);
                var speechOutput = generateSpecificInfoMessage(slots, person);
                var repromptSpeech = "Would you like to find another Deutscher? Say yes or no";
                this.attributes.lastSearch.lastSpeech = speechOutput;
                this.handler.state = states.SEARCHMODE;
                this.emit(":askWithCard", speechOutput, repromptSpeech, cardContent.title, cardContent.body, cardContent.image);
                // this.emitWithState("TellMeThisIntent");
            } else {
                console.log("no infoType was provided.");
                output = generateSearchResultsMessage(searchQuery, searchResults.results);
                this.attributes.lastSearch.lastSpeech = output;
                // this.emit(":ask", generateSearchResultsMessage(searchQuery,searchResults.results));
                this.emit(":ask", output);
            }
        } else { //no match found
            console.log("no match found");
            console.log("searchQuery was  = " + searchQuery);
            console.log("searchResults.results was  = " + searchResults);
            output = generateSearchResultsMessage(searchQuery, searchResults.results);
            this.attributes.lastSearch.lastSpeech = output;
            // this.emit(":ask", generateSearchResultsMessage(searchQuery,searchResults.results));
            this.emit(":ask", output);
        }
    } else {
        console.log("no searchable slot was provided");
        console.log("searchQuery was  = " + searchQuery);
        console.log("searchResults.results was  = " + searchResults);

        this.emit(":ask", generateSearchResultsMessage(searchQuery, false));
    }
}
// =====================================================================================================
// ------------------------------- Section 3. Generating Speech Messages -------------------------------
// =====================================================================================================

function generateNextPromptMessage(person, mode) {
    var infoTypes = ["department", "title", "phone number", "seat location"];
    var prompt;

    if (mode == "current") {
        // if the mode is current, we should give more informaiton about the current contact
        prompt = ". You can say - tell me more, or  tell me " + genderize("his-her", person.gender) + " " + infoTypes[getRandom(0, infoTypes.length - 1)];
    }
    //if the mode is general, we should provide general help information
    else if (mode == "general") {
        prompt = ". " + getGenericHelpMessage(data);
    }
    return prompt;
}

//this might no neccessary
function generateSendingCardToAlexaAppMessage(person, mode) {
    var sentence = "I have sent " + person.firstName + "'s contact card to your Alexa app" + generateNextPromptMessage(person, mode);
    return sentence;
}


// VERY FIRST RESPONSE
function generateSearchResultsMessage(searchQuery, results) {
    var sentence;
    var details;
    var prompt;

    if (results) {
        switch (true) {
            case (results.length == 0):
                sentence = "Hmm. I couldn't find " + searchQuery + ". " + getGenericHelpMessage(data);
                break;
            case (results.length == 1):
                var person = results[0];
                details = person.firstName + " " + person.lastName + " is " + person.title + ", based out of " + person.cityName + ". " + genderize("his-her", person.gender) + " phone number is " + person.number + " . ";
                prompt = generateNextPromptMessage(person, "current");
                sentence = details + prompt;
                console.log(sentence);
                break;
            case (results.length > 1):
                sentence = "I found " + results.length + " matching results";
                break;
        }
    } else {
        sentence = "Sorry, I didn't quite get that. " + getGenericHelpMessage(data);
    }
    return sentence;
}

function getGenericHelpMessage(data) {
    // var sentences = ["ask - who is " + getRandomName(data), "say - find an Deutscher in " + getRandomCity(data)];
    var sentences = ["ask - who is " + getRandomName(data), "say - find an Deutscher in " + getRandomDepartment(data) + " department."];
    return "You can " + sentences[getRandom(0, sentences.length - 1)];
}

function generateSearchHelpMessage(gender) {
    var sentence = "Sorry, I don't know that. You can ask me - what's " + genderize("his-her", gender) + " department, phone number, seat location or give me " + genderize("his-her", gender) + " title";
    return sentence;
}

//When Alexa is asked "Tell me more"
function generateTellMeMoreMessage(person) {
    // var sentence = person.firstName + " joined the Deutsch in " + person.joinDate + ". " + genderize("his-her", person.gender) + " department is " + person.department + " . " + generateSendingCardToAlexaAppMessage(person, "general");
    var sentence = person.firstName + "'s " + "department is " + person.department + " and " + genderize("his-her", person.gender) + " phone number is " + person.number + " and " + genderize("his-her", person.gender) + " seat location is " + person.seatlocation + " on " + whichFloor(person.seatlocation) + "th floor. " + generateSendingCardToAlexaAppMessage(person, "general");
    return sentence;
}

function generateSpecificInfoMessage(slots, person) {
    var infoTypeValue;
    var sentence;

    infoTypeValue = slots.infoType.value;

    if (slots.infoType.value == "phone number" || slots.infoType.value == "number") {
        infoTypeValue = "number";
        console.log("remove space between words");
    } else if (slots.infoType.value == "seat location" || slots.infoType.value == "location" || slots.infoType.value == "seat") {
        infoTypeValue = "seatlocation";
        console.log("remove space between words");
    } else {
        console.log("no removing space needed");
        infoTypeValue = slots.infoType.value;
    }

    // sentence = person.firstName + "'s " + infoTypeValue.toLowerCase() + " is - " + person[infoTypeValue.toLowerCase()] + " . Would you like to find another Deutscher? " + getGenericHelpMessage(data);

    if (infoTypeValue == "seatlocation") {
        sentence = person.firstName + "'s seat location is - " + person[infoTypeValue] + " on " + whichFloor(person[infoTypeValue]) + "th floor. Would you like to find another Deutscher? " + getGenericHelpMessage(data);
    } else {
        sentence = person.firstName + "'s " + infoTypeValue + " is - " + person[infoTypeValue] + ". Would you like to find another Deutscher? " + getGenericHelpMessage(data);
    }
    // return optimizeForSpeech(sentence);
    return sentence;
}

exports.handler = function (event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    alexa.registerHandlers(newSessionHandlers, startSearchHandlers, descriptionHandlers, multipleSearchResultsHandlers);
    alexa.execute();
};

// =====================================================================================================
// ------------------------------------ Section 4. Helper Functions  -----------------------------------
// =====================================================================================================
// For more helper functions, visit the Alexa cookbook at https://github.com/alexa/alexa-cookbook
//======================================================================================================

function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function getRandomCity(arrayOfStrings) {
    //return arrayOfStrings[getRandom(0, data.length - 1)].cityName;
}

function getRandomName(arrayOfStrings) {
    var randomNumber = getRandom(0, data.length - 1);
    arrayOfStrings = arrayOfStrings.toLowerCase();
    return arrayOfStrings[randomNumber].firstName + " " + arrayOfStrings[randomNumber].lastName;
}

function getRandomDepartment(arrayOfStrings) {
    return arrayOfStrings[getRandom(0, data.length - 1)].department;
}

function titleCase(str) {
    return str.replace(str[0], str[0].toUpperCase());
}

function generateCard(person) {
    var cardTitle = "Contact Info for " + titleCase(person.firstName) + " " + titleCase(person.lastName);
    // var cardBody = "Department: " + "@" + person.department + " \n" + "Title: " + person.title + " \n" + "number: " + person.number;
    var cardBody = "Department: " + person.department + " \n" + "Title: " + person.title + " \n" + "number: " + person.number + " \n" + "Seat Location: " + person.seatlocation;
    var imageObj = {
        smallImageUrl: "https://s3.amazonaws.com/deutscherlookup/" + person.firstName + ".jpg",
        largeImageUrl: "https://s3.amazonaws.com/deutscherlookup/" + person.firstName + ".jpg",
    };
    return {
        "title": cardTitle,
        "body": cardBody,
        "image": imageObj
    };
}

function loopThroughArrayOfObjects(arrayOfStrings) {
    var joinedResult = "";
    // Looping through the each object in the array
    for (var i = 0; i < arrayOfStrings.length; i++) {
        //concatenating names (firstName + lastName ) for each item
        joinedResult = joinedResult + ", " + arrayOfStrings[i].firstName + " " + arrayOfStrings[i].lastName;
    }
    return joinedResult;
}

function genderize(type, gender) {
    var pronouns = {
        "m": {
            "he-she": "he",
            "his-her": "his",
            "him-her": "him"
        },
        "f": {
            "he-she": "she",
            "his-her": "her",
            "him-her": "her"
        }
    };
    return pronouns[gender][type];
}

function sanitizeSearchQuery(searchQuery) {
    searchQuery = searchQuery.replace(/’s/g, "").toLowerCase();
    searchQuery = searchQuery.replace(/'s/g, "").toLowerCase();
    return searchQuery;
}

function optimizeForSpeech(str) {
    var optimizedString = str.replace("title", "title");
    return optimizedString;
}

function isSlotValid(request, slotName) {
    var slot = request.intent.slots[slotName];
    //console.log("request = "+JSON.stringify(request)); //uncomment if you want to see the request
    var slotValue;

    //if we have a slot, get the text and store it into speechOutput
    if (slot && slot.value) {
        //we have a value in the slot
        slotValue = slot.value.toLowerCase();
        return slotValue;
    } else {
        //we didn't get a value in the slot.
        return false;
    }
}

function isInArray(value, array) {
    return array.indexOf(value) > -1;
}

function isInfoTypeValid(infoType) {
    var validTypes = ["department", "title", "phone number", "seat location"];
    return isInArray(infoType, validTypes);
}

function whichFloor(seatlocation) {
    var floorNumber = String(seatlocation).charAt(1);
    var floor = '1' + floorNumber;
    return floor;
}